# Nebula X Backend — Train Condition Monitoring (Problem Statement 3)

> Official brief (from the Day-1 slides): *"Rail vehicles generate large
> volumes of sensor data from their onboard subsystems during daily
> operations. Relying on manual inspection or fixed thresholds to detect
> faults and anomalies are not ideal. **Your mission**: develop an automated
> fault and anomaly detection solution using the data provided, and build
> an app that displays the actionable prediction results clearly."*

That last clause — "displays the actionable prediction results clearly" —
is doing a lot of work in the judging. This backend is built so the
dashboard and chatbot can both do that without ever touching a model
directly. See **"How to stand out"** at the bottom for how to use this
architecture to actually win points on it.

## How the pieces connect

```
  4 subsystems, each pluggable rule-based OR ML (one config flag each):
  ┌─────────┐ ┌─────────┐ ┌───────────────────┐ ┌─────┐
  │  door   │ │   acv   │ │ rail_corrugation  │ │ shm │
  └────┬────┘ └────┬────┘ └─────────┬─────────┘ └──┬──┘
       │           │                │              │
       └─────────────────┬──────────┴──────────────┘
                          ▼
              app/services/modules/registry.py
           (all 4 return the SAME alert-dict shape)
                          │
                          ▼
              app/services/alert_engine.py  ◄──── live LTA feeds
              (ONE unified alert feed)            (TrainServiceAlerts,
                          │                        FacilitiesMaintenance)
              ┌───────────┴───────────┐
              ▼                       ▼
     GET /api/alerts          POST /api/chat
     GET /api/dashboard/      (Gemini + tool-calling
       summary                 into the SAME alert feed)
              │                       │
              ▼                       ▼
      Thuzar's dashboard        May's chatbot UI
```

**The key idea, unchanged from before but now load-bearing for your
"4 subsystems, 2 undecided" situation:** the dashboard and chatbot never
call a model or a rule function directly. Everything funnels through one
`DiagnosticModule` interface → one `alert_engine.ingest()` call → one
`UnifiedAlert` feed. That's what makes the following all *config changes,
not code changes*:

- swapping a sample model file for your teammate's real tuned one
- flipping door/ACV from rule-based to ML once he decides
- adding a 5th subsystem later

## Project layout

```
app/
  main.py                    FastAPI app + router registration + module warmup
  config.py                  All env-driven settings, incl. the 4 mode switches
  models/schemas.py          Pydantic response models (UnifiedAlert, chat I/O)
  services/
    diagnostics.py            Your original door/ACV rule logic, untouched
    modules/                   ★ the swappable layer ★
      base.py                   DiagnosticModule interface (one method: predict)
      generic_xgb.py             Reusable XGBoost wrapper (classifier or regressor)
      door_module.py              rule (default) or model, via DOOR_MODE
      acv_module.py               rule (default) or model, via ACV_MODE
      rail_corrugation_module.py  model only (XGBClassifier, 3-class)
      shm_module.py                model only (XGBRegressor)
      registry.py                  builds all 4 from config; add subsystem #5 here
    alert_engine.py            Merges module output + live LTA alerts -> UnifiedAlert feed
    lta_client.py               Cached async wrapper around LTA DataMall APIs
    csv_formatter.py             Produces the *_predictions.csv submission file
  chatbot/
    tools.py                   Functions the LLM is allowed to call
    chat_engine.py               Gemini (Vertex AI or API key) tool-calling loop
  routers/
    predictions.py  alerts.py  lta.py  chat.py  dashboard.py
data/
  rail_corrugation_xgb.json, shm_xgb.json     ⚠️ SAMPLE files, replace when tuned
  model_feature_schemas.json                    ⚠️ the ONE file to edit per model change
Dockerfile, requirements.txt, .env.example
```

## The swap points, explicitly

**Door / ACV — rule vs model (your friend's open decision):**
Set `DOOR_MODE` / `ACV_MODE` to `rule` (default, uses your original
variance/threshold logic in `diagnostics.py`) or `model` (loads an
XGBoost file via `DOOR_MODEL_PATH` / `ACV_MODEL_PATH`). Nothing else in the
codebase needs to change — `door_module.py` and `acv_module.py` already
have both code paths written; only the flag decides which runs. When he
tunes an actual model, drop the file in `data/`, fill in that subsystem's
block in `data/model_feature_schemas.json`, set the mode to `model`,
redeploy.

**Rail corrugation / SHM — sample models today:**
The two `*_xgb.json` files you sent are the example/sample models from the
brief, not your teammate's tuned output. Swapping them for the real ones
later is: overwrite the file (same filename, or point
`RAIL_CORRUGATION_MODEL_PATH` / `SHM_MODEL_PATH` at a new one) + update
`num_features_expected` / `feature_order` / `class_labels` (or
`risk_threshold`) in `model_feature_schemas.json`. No code change. The
`/api/predictions/{subsystem}` endpoint validates column count up front and
returns a clear 400 instead of a silently wrong prediction if the schema's
out of sync.

**A genuinely nice demo moment:** hit `GET /api/predictions/modes` live —
it returns `{"door": "rule", "acv": "rule", "rail_corrugation": "model",
"shm": "model"}`. You can literally show judges "here's our current
config" and explain you can flip any subsystem without touching code.

## The simplest possible explanation of how it all connects

Imagine 3 people in a room: the **Operator** (uses the dashboard), the
**Assistant** (the chatbot/AI), and the **Records Clerk** (your backend
server, which is the only one allowed to touch the real data).

1. Operator asks the Assistant a question, e.g. *"any critical faults?"*
2. The Assistant is smart but has **no memory of your trains** — it doesn't
   know any real numbers. So instead of guessing, it turns to the Clerk and
   says: *"Can you check the critical alerts list for me?"*
3. The Clerk actually looks it up — checks the one shared alert list that
   your 4 models (door, ACV, rail corrugation, SHM) and the live LTA feed
   all write into.
4. The Clerk hands the real answer back to the Assistant.
5. The Assistant turns that into a nice sentence and replies to the Operator.

**The Operator never sees steps 2–4** — they just see "I typed a question,
I got an answer" in one go. Steps 2–4 happen automatically, inside your
server, in under a couple of seconds, possibly repeating 2-3 times if the
Assistant needs to check more than one thing before it's confident enough
to answer.

**Why it's built this way (and not "just ask ChatGPT"):** an AI on its own
will happily make up a plausible-sounding number if you don't stop it. By
forcing it to always go through the Clerk first, it becomes physically
unable to lie about your data — it can only repeat what your models and
your live feeds actually found. That's the one sentence to say to judges
if they ask "how do you know the chatbot isn't hallucinating."

**How your dashboard connects to the same brain:** the dashboard doesn't
talk to the Assistant at all for its charts/status boards — it goes
straight to the Clerk too (`GET /api/alerts`), skipping the Assistant
entirely, because a dashboard just needs the raw numbers, not a sentence.
Only the chat box talks to the Assistant. Both are reading from the exact
same list, so the chatbot's answer and the dashboard's display can never
contradict each other.

---

### The technical version, if you want to see the actual steps

Short answer: **from the user's point of view it's one request, one
answer** — they type a question, they get a reply. The "back and forth"
happens *inside* your backend, between your server and Google's Gemini API,
before your server replies. Concretely, for a question like *"any critical
faults right now?"*:

1. **Frontend → backend:** dashboard/chat UI does `POST /api/chat` with
   `{ session_id, message }`. One HTTP call.
2. **Backend → Gemini (round 1):** `chat_engine.py` sends the conversation
   history + the list of tools it's allowed to use (`get_active_alerts`,
   `get_train_service_status`, `get_station_crowd_density`) to Gemini.
3. **Gemini decides it needs data**, and replies not with text but with a
   structured "please call `get_active_alerts(min_severity='critical')`"
   instruction. It does NOT call anything itself — Gemini can only *ask*.
4. **Backend runs the actual Python function** (`tools.py` →
   `alert_engine.list_alerts(...)`), which reads the SAME in-memory alert
   feed the dashboard reads. This never leaves your server or hits an
   external API unless the tool itself needs to (e.g.
   `get_train_service_status` calls LTA DataMall, through the same cache
   everything else uses).
5. **Backend → Gemini (round 2):** sends the tool's result back as a new
   turn.
6. **Gemini now has real numbers** and replies with plain text: *"2
   critical alerts: SHM risk on Car 03 (score 91.2), and a NEL service
   disruption between Punggol and Sengkang."*
7. **Backend → frontend:** the one `/api/chat` response finally returns,
   containing `reply` (what to show the user) and `tool_calls` (what it
   looked up — handy for a "thinking..." trace in the UI so it doesn't feel
   like a black box).

Steps 2–6 can repeat up to `MAX_TOOL_ROUNDS` (5) times if Gemini needs
several pieces of data before it's confident enough to answer — still all
inside that one `/api/chat` call. The chatbot is **never allowed to
hallucinate a number**: the system prompt explicitly tells it to call a
tool before answering anything about alerts/faults/status, and it can only
call the functions in `tools.py`, which only ever return real data from
your alert engine or LTA. That grounding is worth calling out to judges —
it's the difference between "a chatbot bolted on top" and "a chatbot that
can't lie about what the models found."

## Connecting to the AI: 3 interchangeable options, one config flag

If your GCP console says **"API Keys are Disallowed"** (common in a
Qwiklabs/sandboxed project), that is your org blocking ONE login method for
Vertex AI, not blocking Vertex AI itself. Google's own console labels the
alternative — **Application Default Credentials (ADC)** — "Recommended,"
and that's exactly what Option B below uses. You almost certainly don't
need OpenAI at all; it's here purely as a break-glass fallback.

**Option A — `gemini_api_key` (fastest, good for local dev today):**
A separate Google product (Gemini Developer API) from Vertex/Agent-Platform
— its keys are unaffected by a Vertex-side "API keys disallowed" policy.
1. Go to https://aistudio.google.com/apikey, create a key.
2. `.env`: `LLM_PROVIDER=gemini_api_key`, `GOOGLE_API_KEY=<the key>`.
3. `uvicorn app.main:app --reload` — chatbot works immediately, no IAM.

**Option B — `vertex` with ADC (recommended; use this for the deployed prototype):**
1. In your GCP project: `gcloud services enable aiplatform.googleapis.com`.
2. Grant the calling identity the **Vertex AI User** role:
   - *Locally*: run `gcloud auth application-default login` (or the
     `setup_adc.sh` one-liner your GCP console shows on the API Keys page)
     — this logs your own account in, no key generated or stored.
   - *On Cloud Run*: IAM & Admin → your project → find the service's
     account (the Compute Engine default one, or whichever Cloud Run
     assigned it) → Grant Access → role "Vertex AI User". Nothing to
     paste into env vars — Cloud Run's own identity handles auth silently.
3. `.env` / Cloud Run env vars: `LLM_PROVIDER=vertex`, `GCP_PROJECT=<your project id>`,
   `GCP_LOCATION=asia-southeast1` (or wherever Vertex AI is enabled for you).
4. No API key anywhere — nothing to leak, nothing to rotate, nothing that expires mid-demo.

**Option C — `openai` (break-glass fallback only):**
Use this only if it turns out neither Google path is reachable on your
actual competition network (rare, but worth having ready).
1. `.env`: `LLM_PROVIDER=openai`, `OPENAI_API_KEY=<your key>`.
2. Nothing else changes — `chat_engine.py` already implements this path
   with the exact same tool-calling logic as the Gemini options.

Switching between all three later is one env var (`LLM_PROVIDER`), nothing
in `tools.py`, the router, or the rest of the app needs to change.

## Step-by-step: getting this running end to end

1. **Local smoke test**
   ```bash
   pip install -r requirements.txt
   cp .env.example .env        # fill in LTA_ACCOUNT_KEY + a Gemini option (A or B above)
   uvicorn app.main:app --reload --port 8080
   # visit http://localhost:8080/docs, try POST /api/predictions/shm with a sample CSV
   ```
2. **Confirm the module switch works** — call `GET /api/predictions/modes`,
   change `DOOR_MODE=model` in `.env` with a placeholder model path, restart,
   call it again, see the value flip. (It'll error on an actual prediction
   until a real door model file exists — that's expected and fine to show:
   "the switch works, the model just isn't tuned yet.")
3. **Wire in a sample telemetry CSV per subsystem** and confirm
   `POST /api/predictions/{subsystem}` returns alerts, and that
   `GET /api/alerts` shows them.
4. **Set up Gemini** (Option A first for speed) and confirm
   `POST /api/chat` with `{"session_id":"t1","message":"any alerts?"}`
   returns a grounded answer (check `tool_calls` in the response to see it
   actually called `get_active_alerts`).
5. **Point Thuzar's dashboard** at `${API_BASE}/api/alerts`,
   `${API_BASE}/api/dashboard/summary`, and wire the chat box to
   `${API_BASE}/api/chat`. Set `ALLOWED_ORIGINS` in your backend's env to
   her dashboard's URL.
6. **Switch to Option B (Vertex)** once IAM is set up, redeploy, confirm
   the chatbot still works — this is the version that actually uses your
   GCP credits.
7. **Deploy to Cloud Run** (below), get the URL, that's your submission link
   (see the two single-URL options below).
8. **When Ren's real models land:** update `data/model_feature_schemas.json`,
   overwrite the two `*_xgb.json` files, redeploy. When your teammate locks
   door/ACV's mode: flip `DOOR_MODE`/`ACV_MODE`, add the model file if he
   went ML, redeploy.

## Deploying to Cloud Run (one environment, per your submission plan)

```bash
export PROJECT_ID=your-gcp-project
export REGION=asia-southeast1

gcloud config set project $PROJECT_ID

gcloud run deploy nebula-x-backend \
  --source . \
  --region $REGION \
  --allow-unauthenticated \
  --set-env-vars LTA_ACCOUNT_KEY=xxx,LLM_PROVIDER=vertex,GCP_PROJECT=$PROJECT_ID,GCP_LOCATION=$REGION,ALLOWED_ORIGINS=https://your-dashboard-url
```

Two ways to satisfy the "single hosted link" submission rule:
1. **Two Cloud Run services** (this backend API + a separate dashboard
   service that calls it via `fetch`). Simplest to iterate on independently.
2. **One service**: have FastAPI also serve the built dashboard as static
   files (`app.mount("/", StaticFiles(directory="dashboard_build", html=True))`
   in `main.py`) so there's one URL, one Cloud Run service.

Because Vertex AI, BigQuery, GCS and Cloud Run all sit in the same GCP
project, no extra credential juggling is needed beyond the one IAM role
above.

## LTA DataMall notes (from the API guide)

- Auth: header `AccountKey: <your key>` on every call (register at
  https://datamall.lta.gov.sg/). No OAuth.
- Base URL: `https://datamall2.mytransport.sg/ltaodataservice`
- Endpoints wired up so far (add more in `lta_client.py` the same way):
  - `TrainServiceAlerts` — ad hoc, live disruptions (section 2.11)
  - `FacilitiesMaintenance` (v2) — ad hoc lift maintenance (section 2.23)
  - `PCDRealTime` / `PCDForecast` — station crowd density (2.24/2.25)
- Responses cap at 500 records/call; page with `$skip=500`, `$skip=1000`, ...
- Each endpoint is cached in-process for a TTL matched to its own
  "Update Freq" (`app/config.py` → `LTA_CACHE_TTL`).

## How to stand out (judged on Innovation / Execution / Impact)

The brief explicitly says: automated detection + **"an app that displays
the actionable prediction results clearly."** Most teams will show a
dashboard with numbers on it. Here's how this architecture lets you go
further in each category:

**Innovation**
- Lead with the unified, source-agnostic alert feed: 4 physically different
  subsystems (door motor current, aircon variance, rail corrugation
  vibration, structural health) all collapse into one severity-ranked feed
  alongside *live* LTA operational data (train disruptions, lift
  maintenance) — a genuinely fused operational picture, not 4 separate
  demos glued together.
- The rule-vs-model toggle isn't just an engineering convenience — frame it
  as a feature: "we can ship a subsystem with proven logic on day 1 and
  swap in a learned model the moment it's ready, with zero downtime and no
  dashboard/chatbot changes." That's a real production concern LTA's own
  engineers would care about.
- Grounded chat, not a chat wrapper: the bot can only answer from tool
  calls into live data (see the flow above) — call this out explicitly, it
  addresses the classic "is this just ChatGPT with extra steps" judge
  question.

**Execution**
- Deployed, working link on Cloud Run > slides. Prioritize getting
  `/api/chat` and `/api/alerts` live over polishing any one model.
- Show the `/api/predictions/modes` endpoint live as proof the swap
  architecture is real, not just described in a README.
- Handle the "model not ready yet" case gracefully in the demo: a clear
  400 with a helpful message (already built in) reads as robustness, not
  breakage, if a teammate's model file is still mid-tuning at judging time.

**Impact**
- Translate model output into operator language, not ML language, in both
  the dashboard and the chatbot: "3 days advance warning before this rail
  segment likely needs maintenance" lands with judges much harder than "SHM
  regressor risk score 91.2." Consider adding a plain-language `impact`
  sentence to `UnifiedAlert` (e.g. in `generic_xgb.py`'s alert dicts) that
  the chatbot can quote directly.
- Since Model 3 in the master doc is a *forecaster* (predicts drift before
  a threshold breach), lean into "early warning lead time" as your impact
  metric during the pitch — it's the one number that separates "detects
  faults" from "prevents faults," which is the stronger story for a "living
  railway whispers secrets" problem statement.
