"""
Chat orchestration. Three interchangeable ways to reach an LLM, picked by
ONE setting (LLM_PROVIDER) -- same pattern as the door/ACV rule-vs-model
switch elsewhere in this backend:

  - LLM_PROVIDER=vertex           -> Gemini via Vertex AI, authenticated with
                                      Application Default Credentials (ADC),
                                      NOT an API key. This is what Google
                                      itself recommends (see Settings > API
                                      Keys in your GCP console) and it's
                                      billed against your hackathon credits.
                                      Local dev: run `gcloud auth application-
                                      default login` once. On Cloud Run: zero
                                      setup beyond granting the service's
                                      account the "Vertex AI User" IAM role.

  - LLM_PROVIDER=gemini_api_key   -> Gemini Developer API with a plain API
                                      key from https://aistudio.google.com.
                                      NOTE: some org policies (like the one in
                                      your screenshot) disable API keys for
                                      Vertex/Agent-Platform specifically --
                                      that restriction does NOT apply to this
                                      separate Developer API, but if your org
                                      blocks it too, use "vertex" (ADC) or
                                      "openai" instead.

  - LLM_PROVIDER=openai           -> OpenAI's API as a fallback, in case
                                      neither Google option is reachable in
                                      your actual competition network. Needs
                                      OPENAI_API_KEY.

Whichever provider is picked, the LOGIC is identical: send the conversation
+ the list of tools the model may call -> if it asks to call one, run the
real Python function in tools.py and feed the result back -> repeat until
it replies with plain text. This happens INSIDE one call to chat(), i.e.
inside one HTTP request from the frontend -- the user only sees one round
trip (ask -> answer), even though the backend may bounce off the LLM 2-3
times behind the scenes to fetch live data first.
"""
import logging
from typing import Any

from app.chatbot.tools import TOOL_IMPLS, TOOL_SPECS
from app.config import get_settings

logger = logging.getLogger("nebula_x.chat")

SYSTEM_PROMPT = """You are the Nebula X operator assistant for LTA's rail \
fault-detection prototype. You help railway operators understand model \
predictions (rail corrugation risk, structural health risk, door/ACV \
diagnostics) and live train service status in plain language during a \
live demo. Always call a tool to get current data before answering a \
question about alerts, faults, or live status -- never guess numbers. \
Keep answers short and operator-friendly (this is being read on a dashboard \
during a demo, not a report)."""

MAX_TOOL_ROUNDS = 5  # safety cap on the back-and-forth per message

_gemini_sessions: dict[str, list[Any]] = {}
_openai_sessions: dict[str, list[dict]] = {}


async def _run_tool(name: str, args: dict[str, Any]) -> dict[str, Any]:
    if name not in TOOL_IMPLS:
        return {"error": f"unknown tool {name}"}
    try:
        return await TOOL_IMPLS[name](**args)
    except Exception as exc:  # noqa: BLE001 - surface the error to the LLM, not a 500
        logger.exception("Tool %s failed", name)
        return {"error": str(exc)}


# ---------------------------------------------------------------------------
# Google Gemini (vertex / gemini_api_key) -- same SDK, same loop, only the
# client construction differs.
# ---------------------------------------------------------------------------

def _get_gemini_client():
    from google import genai

    settings = get_settings()
    if settings.LLM_PROVIDER == "gemini_api_key":
        if not settings.GOOGLE_API_KEY:
            raise RuntimeError("GOOGLE_API_KEY is not set (LLM_PROVIDER=gemini_api_key).")
        return genai.Client(api_key=settings.GOOGLE_API_KEY), settings.GEMINI_MODEL
    # default: vertex, using ADC (no key at all)
    if not settings.GCP_PROJECT:
        raise RuntimeError("GCP_PROJECT is not set (LLM_PROVIDER=vertex).")
    return (
        genai.Client(vertexai=True, project=settings.GCP_PROJECT, location=settings.GCP_LOCATION),
        settings.VERTEX_MODEL,
    )


async def _chat_gemini(session_id: str, message: str) -> tuple[str, list[dict]]:
    from google.genai import types

    client, model = _get_gemini_client()

    history = _gemini_sessions.setdefault(session_id, [])
    history.append(types.Content(role="user", parts=[types.Part(text=message)]))

    tool = types.Tool(function_declarations=[
        types.FunctionDeclaration(name=t["name"], description=t["description"], parameters=t["parameters"])
        for t in TOOL_SPECS
    ])
    config = types.GenerateContentConfig(system_instruction=SYSTEM_PROMPT, tools=[tool])

    tool_calls_made: list[dict] = []
    for _ in range(MAX_TOOL_ROUNDS):
        resp = client.models.generate_content(model=model, contents=history, config=config)
        candidate = resp.candidates[0]
        history.append(candidate.content)

        function_calls = [p.function_call for p in candidate.content.parts if p.function_call]
        if not function_calls:
            final_text = "".join(p.text or "" for p in candidate.content.parts)
            return final_text, tool_calls_made

        response_parts = []
        for fc in function_calls:
            args = dict(fc.args or {})
            result = await _run_tool(fc.name, args)
            tool_calls_made.append({"name": fc.name, "args": args, "result": result})
            response_parts.append(types.Part.from_function_response(name=fc.name, response=result))
        history.append(types.Content(role="user", parts=response_parts))

    return "I'm having trouble getting a final answer -- please try rephrasing.", tool_calls_made


# ---------------------------------------------------------------------------
# OpenAI fallback -- same tool-calling idea, OpenAI's own SDK/schema shape.
# ---------------------------------------------------------------------------

async def _chat_openai(session_id: str, message: str) -> tuple[str, list[dict]]:
    import json

    from openai import AsyncOpenAI

    settings = get_settings()
    if not settings.OPENAI_API_KEY:
        raise RuntimeError("OPENAI_API_KEY is not set (LLM_PROVIDER=openai).")
    client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)

    history = _openai_sessions.setdefault(session_id, [])
    if not history:
        history.append({"role": "system", "content": SYSTEM_PROMPT})
    history.append({"role": "user", "content": message})

    tools = [
        {"type": "function", "function": {"name": t["name"], "description": t["description"], "parameters": t["parameters"]}}
        for t in TOOL_SPECS
    ]

    tool_calls_made: list[dict] = []
    for _ in range(MAX_TOOL_ROUNDS):
        resp = await client.chat.completions.create(
            model=settings.OPENAI_MODEL, messages=history, tools=tools
        )
        choice = resp.choices[0].message
        history.append(choice.model_dump(exclude_none=True))

        if not choice.tool_calls:
            return choice.content or "", tool_calls_made

        for tc in choice.tool_calls:
            args = json.loads(tc.function.arguments or "{}")
            result = await _run_tool(tc.function.name, args)
            tool_calls_made.append({"name": tc.function.name, "args": args, "result": result})
            history.append({"role": "tool", "tool_call_id": tc.id, "content": json.dumps(result)})

    return "I'm having trouble getting a final answer -- please try rephrasing.", tool_calls_made


# ---------------------------------------------------------------------------
# Entry point used by the /api/chat router -- picks the provider by config.
# ---------------------------------------------------------------------------

async def chat(session_id: str, message: str) -> tuple[str, list[dict]]:
    settings = get_settings()
    if settings.LLM_PROVIDER == "openai":
        return await _chat_openai(session_id, message)
    return await _chat_gemini(session_id, message)
