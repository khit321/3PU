"""
The functions the chatbot LLM is allowed to call. Each one returns a plain
JSON-serializable dict -- the LLM never touches a model, a DataFrame, or the
LTA API directly, it only sees these summaries. Add a new capability to the
chatbot by adding a function here + its entry in TOOL_SPECS below; nothing
else needs to change.
"""
from typing import Any

from app.models.schemas import Severity
from app.services import alert_engine
from app.services.lta_client import get_lta_client


async def get_active_alerts(min_severity: str = "warning") -> dict[str, Any]:
    """Return current fault/anomaly alerts across all assets and sources."""
    sev = Severity(min_severity)
    alerts = alert_engine.list_alerts(min_severity=sev)
    return {
        "count": len(alerts),
        "alerts": [
            {
                "id": a.id,
                "source": a.source,
                "asset_id": a.asset_id,
                "severity": a.severity.value,
                "title": a.title,
                "detail": a.detail,
                "timestamp": a.timestamp.isoformat(),
            }
            for a in alerts
        ],
    }


async def get_train_service_status() -> dict[str, Any]:
    """Live LTA train service status (delays/disruptions), straight from DataMall."""
    lta = get_lta_client()
    data = await lta.train_service_alerts()
    values = data.get("value", [])
    if not values:
        return {"status": "All lines reporting normal service."}
    return {"status": "Disruption(s) reported", "lines": values}


async def get_station_crowd_density(train_line: str) -> dict[str, Any]:
    """Real-time crowd density for a given train line, e.g. NEL, EWL, CCL."""
    lta = get_lta_client()
    data = await lta.station_crowd_density_realtime(train_line)
    return {"train_line": train_line, "stations": data.get("value", [])}


# ---- Tool specs (Gemini/Vertex function-calling format; see chat_engine.py
# for how these get wired into the GenerateContentConfig) ----

TOOL_SPECS = [
    {
        "name": "get_active_alerts",
        "description": (
            "Get the current list of fault/anomaly alerts detected by our models "
            "(rail corrugation classifier, structural health monitor, door diagnostics) "
            "plus live LTA operational alerts. Use this whenever the operator asks "
            "'what's wrong', 'any faults', 'show me alerts', or asks about a specific asset."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "min_severity": {
                    "type": "string",
                    "enum": ["normal", "warning", "critical"],
                    "description": "Only return alerts at or above this severity. Default 'warning'.",
                }
            },
        },
    },
    {
        "name": "get_train_service_status",
        "description": "Get live train service status/disruptions across all MRT/LRT lines from LTA DataMall.",
        "parameters": {"type": "object", "properties": {}},
    },
    {
        "name": "get_station_crowd_density",
        "description": "Get real-time station crowd density for a specific train line.",
        "parameters": {
            "type": "object",
            "properties": {
                "train_line": {
                    "type": "string",
                    "description": "Line code, e.g. NEL, EWL, CCL, NSL, DTL, TEL, BPL, SLRT, PLRT, CGL.",
                }
            },
            "required": ["train_line"],
        },
    },
]

TOOL_IMPLS = {
    "get_active_alerts": get_active_alerts,
    "get_train_service_status": get_train_service_status,
    "get_station_crowd_density": get_station_crowd_density,
}
