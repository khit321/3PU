"""
Central config, read from environment variables (Cloud Run injects these
from the service's --set-env-vars / --set-secrets at deploy time).
"""
import json
import os
from functools import lru_cache


class Settings:
    # --- LTA DataMall ---
    LTA_ACCOUNT_KEY: str = os.getenv("LTA_ACCOUNT_KEY", "")
    LTA_BASE_URL: str = os.getenv(
        "LTA_BASE_URL", "https://datamall2.mytransport.sg/ltaodataservice"
    )
    # seconds to cache each LTA endpoint's response before re-fetching.
    # Keep >= the API's own "Update Freq" (see LTA_DataMall_API_User_Guide.pdf)
    # so we don't burn quota polling faster than the data actually changes.
    LTA_CACHE_TTL = {
        "TrainServiceAlerts": 30,        # ad hoc, but cheap + safety-critical -> poll often
        "FacilitiesMaintenance": 300,    # ad hoc, low volatility
        "PCDRealTime": 600,              # 10 min update freq
        "PCDForecast": 1800,             # 30 min update freq
        "FaultyTrafficLights": 120,
        "TrafficIncidents": 60,
        "default": 300,
    }

    # --- Model artifacts (bundled into the container image, see Dockerfile) ---
    # These are SAMPLE files today. Swapping in a teammate's newly-tuned
    # model is just: overwrite the file (or point the *_MODEL_PATH env var
    # at a new filename) + update data/model_feature_schemas.json. No code
    # change, no router change.
    MODEL_DIR: str = os.getenv("MODEL_DIR", os.path.join(os.path.dirname(__file__), "..", "data"))
    RAIL_CORRUGATION_MODEL_PATH: str = os.getenv(
        "RAIL_CORRUGATION_MODEL_PATH", os.path.join(MODEL_DIR, "rail_corrugation_xgb.json")
    )
    SHM_MODEL_PATH: str = os.getenv("SHM_MODEL_PATH", os.path.join(MODEL_DIR, "shm_xgb.json"))
    # Not present yet -- only read if DOOR_MODE / ACV_MODE is switched to "model".
    DOOR_MODEL_PATH: str = os.getenv("DOOR_MODEL_PATH", os.path.join(MODEL_DIR, "door_xgb.json"))
    ACV_MODEL_PATH: str = os.getenv("ACV_MODEL_PATH", os.path.join(MODEL_DIR, "acv_xgb.json"))
    FEATURE_SCHEMA_PATH: str = os.getenv(
        "FEATURE_SCHEMA_PATH", os.path.join(MODEL_DIR, "model_feature_schemas.json")
    )

    # --- Per-subsystem mode switch: "rule" (hand-written logic) or "model" (XGBoost) ---
    # This is the single flag your teammate flips once he decides on door/ACV.
    # rail_corrugation and shm only have a "model" implementation right now.
    DOOR_MODE: str = os.getenv("DOOR_MODE", "rule")
    ACV_MODE: str = os.getenv("ACV_MODE", "rule")
    RAIL_CORRUGATION_MODE: str = os.getenv("RAIL_CORRUGATION_MODE", "model")
    SHM_MODE: str = os.getenv("SHM_MODE", "model")

    # --- Chatbot / LLM: one flag picks the provider, nothing else changes ---
    # "vertex"          -> Vertex AI Gemini, authenticated with Application
    #                      Default Credentials (ADC), NOT an API key. This is
    #                      Google's own recommended method and works even
    #                      when an org policy disables API keys (as in a
    #                      locked-down Qwiklabs project). Needs: GCP_PROJECT,
    #                      GCP_LOCATION, and the "Vertex AI User" IAM role on
    #                      whatever identity is calling it (your local gcloud
    #                      login, or the Cloud Run service's own account).
    # "gemini_api_key"  -> Gemini Developer API (https://aistudio.google.com),
    #                      a separate product from Vertex/Agent-Platform --
    #                      its own API keys aren't affected by a Vertex-side
    #                      "API keys disallowed" org policy. Fastest to set
    #                      up (one key, no IAM) if you want a quick local test.
    # "openai"          -> fallback if neither Google path is reachable in
    #                      your actual competition network. Needs OPENAI_API_KEY.
    LLM_PROVIDER: str = os.getenv("LLM_PROVIDER", "vertex")
    GCP_PROJECT: str = os.getenv("GCP_PROJECT", "")
    GCP_LOCATION: str = os.getenv("GCP_LOCATION", "asia-southeast1")
    VERTEX_MODEL: str = os.getenv("VERTEX_MODEL", "gemini-2.5-flash")
    GOOGLE_API_KEY: str = os.getenv("GOOGLE_API_KEY", "")
    GEMINI_MODEL: str = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
    OPENAI_MODEL: str = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

    # --- Storage (where uploaded telemetry / generated *_predictions.csv live) ---
    # Local disk works fine for the demo; GCS is a one-line swap for real persistence.
    STORAGE_BACKEND: str = os.getenv("STORAGE_BACKEND", "local")  # "local" | "gcs"
    GCS_BUCKET: str = os.getenv("GCS_BUCKET", "")
    LOCAL_STORAGE_DIR: str = os.getenv("LOCAL_STORAGE_DIR", "/tmp/nebula_x_data")

    # --- CORS (Thuzar's dashboard origin) ---
    ALLOWED_ORIGINS = [o.strip() for o in os.getenv("ALLOWED_ORIGINS", "*").split(",")]


@lru_cache
def get_settings() -> Settings:
    return Settings()


@lru_cache
def get_feature_schema() -> dict:
    """The one file to edit when a model changes -- see
    data/model_feature_schemas.json. Cached; if you edit it while the
    server is running, restart to pick up changes."""
    with open(get_settings().FEATURE_SCHEMA_PATH) as f:
        return json.load(f)
