from datetime import datetime
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field


class Severity(str, Enum):
    normal = "normal"
    warning = "warning"
    critical = "critical"


class UnifiedAlert(BaseModel):
    """The single shape the dashboard renders and the chatbot reasons over,
    regardless of whether it came from a model or a live LTA feed."""

    id: str
    source: str  # "rail_corrugation_model" | "shm_model" | "door_diagnostics" | "lta_train_service_alerts" | ...
    asset_id: Optional[str] = None
    severity: Severity
    title: str
    detail: str
    timestamp: datetime
    raw: Optional[dict[str, Any]] = None


class ChatMessage(BaseModel):
    role: str  # "user" | "assistant"
    content: str


class ChatRequest(BaseModel):
    session_id: str
    message: str


class ChatResponse(BaseModel):
    session_id: str
    reply: str
    tool_calls: list[dict[str, Any]] = Field(default_factory=list)
