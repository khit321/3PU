from fastapi import APIRouter

from app.chatbot.chat_engine import chat as run_chat
from app.models.schemas import ChatRequest, ChatResponse

router = APIRouter(prefix="/api/chat", tags=["chat"])


@router.post("", response_model=ChatResponse)
async def chat_endpoint(req: ChatRequest):
    reply, tool_calls = await run_chat(req.session_id, req.message)
    return ChatResponse(session_id=req.session_id, reply=reply, tool_calls=tool_calls)
