"""
Passthrough + refresh endpoints for the raw LTA DataMall feeds, in case the
dashboard wants to show live data directly (e.g. a "train status" widget)
rather than only the merged alert feed.
"""
from fastapi import APIRouter, Depends

from app.services import alert_engine
from app.services.lta_client import LTAClient, get_lta_client

router = APIRouter(prefix="/api/lta", tags=["lta"])


@router.get("/train-service-alerts")
async def train_service_alerts(lta: LTAClient = Depends(get_lta_client)):
    return await lta.train_service_alerts()


@router.get("/facilities-maintenance")
async def facilities_maintenance(line: str | None = None, lta: LTAClient = Depends(get_lta_client)):
    return await lta.facilities_maintenance(line=line)


@router.get("/crowd-density/{train_line}")
async def crowd_density(train_line: str, lta: LTAClient = Depends(get_lta_client)):
    return await lta.station_crowd_density_realtime(train_line)


@router.post("/refresh")
async def refresh(lta: LTAClient = Depends(get_lta_client)):
    """Pull the latest LTA feeds and merge any new items into the unified
    alert feed. Call this on a schedule (e.g. Cloud Scheduler hitting this
    endpoint every minute) or have the dashboard trigger it on load."""
    created = await alert_engine.refresh_lta_alerts(lta)
    return {"new_alerts": len(created)}
