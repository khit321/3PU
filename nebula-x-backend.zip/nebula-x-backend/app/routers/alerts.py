from typing import Optional

from fastapi import APIRouter, Query

from app.models.schemas import Severity, UnifiedAlert
from app.services import alert_engine

router = APIRouter(prefix="/api/alerts", tags=["alerts"])


@router.get("", response_model=list[UnifiedAlert])
async def list_alerts(min_severity: Optional[Severity] = Query(default=None)):
    """This is the ONE endpoint Thuzar's dashboard needs to poll (e.g. every
    5-10s) to render the alert feed / status board, regardless of whether an
    alert came from a model or a live LTA feed."""
    return alert_engine.list_alerts(min_severity=min_severity)
