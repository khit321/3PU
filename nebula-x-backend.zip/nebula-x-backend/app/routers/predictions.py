"""
ONE endpoint for all 4 subsystems. Which subsystem runs rule-based logic vs
an XGBoost model is decided entirely by config (DOOR_MODE, ACV_MODE,
RAIL_CORRUGATION_MODE, SHM_MODE in .env) -- this router never branches on
that, it just calls whatever module the registry hands it.
"""
import io

import pandas as pd
from fastapi import APIRouter, File, HTTPException, UploadFile

from app.services import alert_engine
from app.services.modules.registry import get_module_registry

router = APIRouter(prefix="/api/predictions", tags=["predictions"])

SUBSYSTEMS = {"door", "acv", "rail_corrugation", "shm"}


@router.post("/{subsystem}")
async def run_prediction(
    subsystem: str,
    file: UploadFile = File(..., description="Telemetry/feature CSV for this subsystem"),
):
    if subsystem not in SUBSYSTEMS:
        raise HTTPException(404, f"Unknown subsystem '{subsystem}'. Choose one of {sorted(SUBSYSTEMS)}.")

    df = pd.read_csv(io.BytesIO(await file.read()))
    module = get_module_registry()[subsystem]

    try:
        alert_dicts = module.predict(df)
    except ValueError as exc:
        # e.g. wrong column count for the loaded model -- surfaced as a
        # clean 400 instead of a silent bad prediction or a raw 500.
        raise HTTPException(400, str(exc)) from exc

    created = alert_engine.ingest(subsystem, alert_dicts)
    return {
        "subsystem": subsystem,
        "mode": module.mode,
        "rows_processed": len(df),
        "new_alerts": len(created),
        "alerts": created,
    }


@router.get("/modes")
async def current_modes():
    """Handy for the dashboard to show 'Door: rule-based | ACV: rule-based |
    Rail corrugation: ML model | SHM: ML model' -- and a nice thing to point
    at live during judging to show the architecture is genuinely swappable."""
    registry = get_module_registry()
    return {name: module.mode for name, module in registry.items()}
