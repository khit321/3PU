"""
One convenience endpoint that bundles everything Thuzar's dashboard needs
for a top-level status view, so the frontend doesn't have to make 4 calls
and stitch them together itself. The dashboard can still hit /api/alerts
directly for the detailed feed.
"""
from fastapi import APIRouter, Depends

from app.models.schemas import Severity
from app.services import alert_engine
from app.services.lta_client import LTAClient, get_lta_client

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])


@router.get("/summary")
async def summary(lta: LTAClient = Depends(get_lta_client)):
    alerts = alert_engine.list_alerts()
    critical = [a for a in alerts if a.severity == Severity.critical]
    warning = [a for a in alerts if a.severity == Severity.warning]

    train_status = await lta.train_service_alerts()
    disrupted_lines = list({v.get("Line") for v in train_status.get("value", [])})

    return {
        "overall_status": "critical" if critical else ("warning" if warning else "normal"),
        "counts": {"critical": len(critical), "warning": len(warning), "total": len(alerts)},
        "top_alerts": alerts[:5],
        "disrupted_lines": disrupted_lines,
    }
