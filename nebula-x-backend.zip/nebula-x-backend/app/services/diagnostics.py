"""
Rule-based diagnostics for door telemetry and ACV (Air-Conditioning Vent /
Aircon) telemetry. This is your original diagnostics.py, unchanged in logic,
just imported into the service layer so the rest of the backend can call it
alongside the two XGBoost models.
"""
import re

import pandas as pd


def analyze_door_data(door_df: pd.DataFrame) -> pd.DataFrame:
    """Analyzes door telemetry and returns anomalous segments."""
    # Parse timestamps
    time_str = door_df["Datetime"].astype(str).str.split("-").apply(lambda x: "-".join(x[:6]))
    door_df["parsed_time"] = pd.to_datetime(time_str, format="%Y-%m-%d-%H-%M-%S", errors="coerce")
    door_df = door_df.sort_values(by="parsed_time").reset_index(drop=True)

    # Identify segments
    active_mask = (
        (door_df["Open command"] == 1)
        | (door_df["Close command"] == 1)
        | (door_df["Door is opening"] == 1)
    )
    door_df["segment_id"] = (~active_mask).cumsum()
    segments = door_df[active_mask].groupby("segment_id")

    results = []
    for _, seg in segments:
        start_time = seg["parsed_time"].min().strftime("%Y-%m-%d %H:%M:%S")
        end_time = seg["parsed_time"].max().strftime("%Y-%m-%d %H:%M:%S")

        # Logic rule: max current > 800mA
        max_current = seg["Motor current(mA)"].max()
        prediction = "Abnormal resistance" if max_current > 800 else "Normal"

        results.append({"start_time": start_time, "end_time": end_time, "prediction": prediction})

    return pd.DataFrame(results)


def analyze_acv_data(acv_df: pd.DataFrame) -> str:
    """Analyzes ACV telemetry and returns a ranked string of faulty cars."""
    car_numbers = list(set(re.findall(r"Car (\d{2})", " ".join(acv_df.columns))))
    car_scores = {}

    for car in car_numbers:
        temp_cols = [c for c in acv_df.columns if f"Car {car}" in c and "Temperatu" in c]
        if temp_cols:
            temp_data = acv_df[temp_cols].apply(pd.to_numeric, errors="coerce")
            car_scores[car] = temp_data.var().sum()  # Rank by highest variance
        else:
            car_scores[car] = 0.0

    # Sort descending and join into a string like "03|01|02|04"
    ranked_cars = sorted(car_scores, key=car_scores.get, reverse=True)
    return "|".join(ranked_cars)
