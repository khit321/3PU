"""
Every subsystem (door, ACV, rail corrugation, SHM, and whatever gets added
next) implements this ONE interface. The router, the alert engine, and the
chatbot only ever talk to a DiagnosticModule -- they don't know or care
whether it's a hand-written rule, a variance calculation, or an XGBoost
model underneath. That's what makes switching a subsystem between
rule-based and ML-based a one-line config change instead of a rewrite.
"""
from abc import ABC, abstractmethod
from typing import Any

import pandas as pd


class DiagnosticModule(ABC):
    name: str
    mode: str  # human-readable, e.g. "rule" or "model" -- shown in API responses

    @abstractmethod
    def predict(self, df: pd.DataFrame) -> list[dict[str, Any]]:
        """Return a list of alert dicts, each with at least:
            severity: "normal" | "warning" | "critical"   (skip "normal" rows entirely)
            title:    short human-readable headline
            detail:   one-sentence explanation
        Optional: asset_id, timestamp, raw (extra data for debugging/audit).
        """
        raise NotImplementedError
