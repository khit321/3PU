"""
ACV (aircon) subsystem. Same swap pattern as door_module.py: ACV_MODE=rule|model.
"""
from datetime import datetime, timezone
from typing import Any

import pandas as pd

from app.config import get_feature_schema, get_settings
from app.services import diagnostics

from .base import DiagnosticModule
from .generic_xgb import GenericXGBModule


class ACVModule(DiagnosticModule):
    name = "acv"

    def __init__(self, mode: str = "rule"):
        self.mode = mode
        self._model_impl = None
        if mode == "model":
            settings = get_settings()
            self._model_impl = GenericXGBModule(
                name="acv",
                model_path=settings.ACV_MODEL_PATH,
                schema=get_feature_schema()["acv"],
                task="classifier",
            )

    def predict(self, df: pd.DataFrame) -> list[dict[str, Any]]:
        if self.mode == "model":
            return self._model_impl.predict(df)
        return self._predict_rule(df)

    @staticmethod
    def _predict_rule(df: pd.DataFrame) -> list[dict[str, Any]]:
        """Ranks cars by temperature variance; the most variable car is
        surfaced as a candidate for inspection."""
        ranking = diagnostics.analyze_acv_data(df)
        cars = [c for c in ranking.split("|") if c]
        if not cars:
            return []
        now = datetime.now(timezone.utc)
        return [{
            "asset_id": f"Car {cars[0]}",
            "severity": "warning",
            "title": "ACV temperature variance ranked highest",
            "detail": f"Ranking (most anomalous first): {ranking}.",
            "timestamp": now,
            "raw": {"ranking": ranking},
        }]
