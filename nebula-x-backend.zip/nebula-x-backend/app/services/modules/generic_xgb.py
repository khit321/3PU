"""
One reusable XGBoost-backed module, driven entirely by config + the feature
schema file. This is what makes swapping in your teammate's real tuned
model a zero-code-change operation:

  1. Drop the new *_xgb.json into data/, pointed to by the relevant
     *_MODEL_PATH setting in .env (or just overwrite the existing filename).
  2. Update that subsystem's entry in data/model_feature_schemas.json
     (feature_order / class_labels / risk_threshold).
  3. Redeploy. Nothing in this file, or in any router, changes.

Used today for rail_corrugation (classifier) and shm (regressor). Also
available for door/acv the moment your teammate finishes tuning an ML
version of those -- just switch DOOR_MODE / ACV_MODE to "model" and point
DOOR_MODEL_PATH / ACV_MODEL_PATH at the new files.
"""
import json
from datetime import datetime, timezone
from typing import Any

import numpy as np
import xgboost as xgb

from .base import DiagnosticModule


class GenericXGBModule(DiagnosticModule):
    def __init__(self, name: str, model_path: str, schema: dict, task: str):
        """
        name:   subsystem name, used in alert titles/ids
        task:   "classifier" (multi:softprob) or "regressor"
        schema: the subsystem's block from data/model_feature_schemas.json
                (needs "class_labels" for classifiers, "risk_threshold" for regressors)
        """
        self.name = name
        self.mode = "model"
        self.task = task
        self.schema = schema

        self.booster = xgb.Booster()
        self.booster.load_model(model_path)
        with open(model_path) as f:
            raw = json.load(f)
        self.num_features = int(raw["learner"]["learner_model_param"]["num_feature"])

    def predict(self, df) -> list[dict[str, Any]]:
        arr = df.values.astype(float)
        if arr.shape[1] != self.num_features:
            raise ValueError(
                f"'{self.name}' model expects {self.num_features} feature columns, got {arr.shape[1]}. "
                "Check data/model_feature_schemas.json against the latest tuned model file."
            )
        preds = self.booster.predict(xgb.DMatrix(arr))
        now = datetime.now(timezone.utc)

        if self.task == "classifier":
            return self._classifier_alerts(preds, now)
        return self._regressor_alerts(preds, now)

    def _classifier_alerts(self, preds, now) -> list[dict[str, Any]]:
        labels = self.schema["class_labels"]
        alerts = []
        for i, row_probs in enumerate(preds):
            top_idx = int(np.argmax(row_probs))
            predicted_class = labels[top_idx]
            severity = "normal" if top_idx == 0 else ("critical" if top_idx == len(labels) - 1 else "warning")
            if severity == "normal":
                continue
            alerts.append({
                "asset_id": f"row_{i}",
                "severity": severity,
                "title": f"{self.name}: {predicted_class}",
                "detail": f"Predicted '{predicted_class}' (confidence {float(row_probs[top_idx]):.0%}).",
                "timestamp": now,
                "raw": {"class_probabilities": {lbl: float(p) for lbl, p in zip(labels, row_probs)}},
            })
        return alerts

    def _regressor_alerts(self, preds, now) -> list[dict[str, Any]]:
        threshold = self.schema["risk_threshold"]
        alerts = []
        for i, raw_score in enumerate(preds):
            score = float(raw_score)
            if score >= threshold:
                severity = "critical"
            elif score >= threshold * 0.7:
                severity = "warning"
            else:
                continue
            alerts.append({
                "asset_id": f"row_{i}",
                "severity": severity,
                "title": f"{self.name}: risk score elevated",
                "detail": f"Risk score {score:.1f} (threshold {threshold:.1f}).",
                "timestamp": now,
                "raw": {"risk_score": score, "threshold": threshold},
            })
        return alerts
