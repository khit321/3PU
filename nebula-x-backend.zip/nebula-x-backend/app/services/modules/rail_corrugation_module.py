from typing import Any

import pandas as pd

from app.config import get_feature_schema, get_settings

from .base import DiagnosticModule
from .generic_xgb import GenericXGBModule


class RailCorrugationModule(DiagnosticModule):
    """XGBClassifier (3-class). The current data/rail_corrugation_xgb.json is
    the sample file from your master doc's dataset -- swap it for your
    teammate's tuned version (same filename, or update
    RAIL_CORRUGATION_MODEL_PATH) and update model_feature_schemas.json's
    "rail_corrugation" block once feature order is finalized. No code
    change needed here."""

    name = "rail_corrugation"

    def __init__(self, mode: str = "model"):
        self.mode = mode
        settings = get_settings()
        self._impl = GenericXGBModule(
            name=self.name,
            model_path=settings.RAIL_CORRUGATION_MODEL_PATH,
            schema=get_feature_schema()["rail_corrugation"],
            task="classifier",
        )

    def predict(self, df: pd.DataFrame) -> list[dict[str, Any]]:
        return self._impl.predict(df)
