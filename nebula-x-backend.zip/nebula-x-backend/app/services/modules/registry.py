"""
One place that knows about all 4 subsystems. Add a 5th subsystem later by
adding one line here -- the router, alert engine, and chatbot need zero
changes to pick it up.
"""
import threading

from app.config import get_settings

from .acv_module import ACVModule
from .door_module import DoorModule
from .rail_corrugation_module import RailCorrugationModule
from .shm_module import SHMModule

_lock = threading.Lock()
_registry: dict | None = None


def build_registry() -> dict:
    settings = get_settings()
    return {
        "door": DoorModule(mode=settings.DOOR_MODE),
        "acv": ACVModule(mode=settings.ACV_MODE),
        "rail_corrugation": RailCorrugationModule(mode=settings.RAIL_CORRUGATION_MODE),
        "shm": SHMModule(mode=settings.SHM_MODE),
    }


def get_module_registry() -> dict:
    global _registry
    with _lock:
        if _registry is None:
            _registry = build_registry()
    return _registry


def reset_registry() -> None:
    """Call this if you change a *_MODE env var at runtime and want the next
    request to pick it up without a full redeploy (e.g. a demo toggle
    endpoint). Not used automatically."""
    global _registry
    with _lock:
        _registry = None
