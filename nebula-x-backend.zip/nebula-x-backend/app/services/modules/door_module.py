"""
Door subsystem. Mode is a config flag (DOOR_MODE=rule|model), so your
teammate can flip it the moment he decides between keeping the
variance/threshold logic or shipping a tuned ML model -- no code change,
no router change, no chatbot change.
"""
from datetime import datetime, timezone
from typing import Any

import pandas as pd

from app.config import get_feature_schema, get_settings
from app.services import diagnostics

from .base import DiagnosticModule
from .generic_xgb import GenericXGBModule


class DoorModule(DiagnosticModule):
    name = "door"

    def __init__(self, mode: str = "rule"):
        self.mode = mode
        self._model_impl = None
        if mode == "model":
            settings = get_settings()
            self._model_impl = GenericXGBModule(
                name="door",
                model_path=settings.DOOR_MODEL_PATH,
                schema=get_feature_schema()["door"],
                task="classifier",  # change to "regressor" if he ships a risk-score model instead
            )

    def predict(self, df: pd.DataFrame) -> list[dict[str, Any]]:
        if self.mode == "model":
            return self._model_impl.predict(df)
        return self._predict_rule(df)

    @staticmethod
    def _predict_rule(df: pd.DataFrame) -> list[dict[str, Any]]:
        """Your original rule: max motor current > 800mA during an
        open/close segment = 'Abnormal resistance'."""
        result_df = diagnostics.analyze_door_data(df)
        now = datetime.now(timezone.utc)
        alerts = []
        for row in result_df.to_dict(orient="records"):
            if row["prediction"] == "Normal":
                continue
            alerts.append({
                "severity": "warning",
                "title": "Abnormal door resistance detected",
                "detail": f"Segment {row['start_time']} -> {row['end_time']}: {row['prediction']}.",
                "timestamp": now,
                "raw": row,
            })
        return alerts
