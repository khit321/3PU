from typing import Any

import pandas as pd

from app.config import get_feature_schema, get_settings

from .base import DiagnosticModule
from .generic_xgb import GenericXGBModule


class SHMModule(DiagnosticModule):
    """XGBRegressor. Same swap-in-place pattern as RailCorrugationModule --
    replace data/shm_xgb.json + the "shm" block in model_feature_schemas.json
    once your teammate's real model is tuned."""

    name = "shm"

    def __init__(self, mode: str = "model"):
        self.mode = mode
        settings = get_settings()
        self._impl = GenericXGBModule(
            name=self.name,
            model_path=settings.SHM_MODEL_PATH,
            schema=get_feature_schema()["shm"],
            task="regressor",
        )

    def predict(self, df: pd.DataFrame) -> list[dict[str, Any]]:
        return self._impl.predict(df)
