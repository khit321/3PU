"""
Merges everything into ONE feed of UnifiedAlert objects:
  - module-derived faults (door, acv, rail_corrugation, shm -- whichever mode
    each is running in, rule-based or ML, doesn't matter here)
  - live LTA operational alerts (TrainServiceAlerts, FacilitiesMaintenance)

This is the single object both Thuzar's dashboard and May's chatbot read
from -- neither of them needs to know an XGBoost model, a rule function, or
an LTA API even exists. It's an in-memory store for the hackathon; swap
`_alerts` for a Firestore/BigQuery table if you want alerts to survive a
container restart.
"""
import hashlib
from datetime import datetime, timezone
from typing import Any, Optional

from app.models.schemas import Severity, UnifiedAlert
from app.services.lta_client import LTAClient

_alerts: dict[str, UnifiedAlert] = {}


def _make_id(*parts: str) -> str:
    return hashlib.sha1("|".join(parts).encode()).hexdigest()[:12]


def upsert(alert: UnifiedAlert) -> None:
    _alerts[alert.id] = alert


def list_alerts(min_severity: Optional[Severity] = None) -> list[UnifiedAlert]:
    order = {Severity.normal: 0, Severity.warning: 1, Severity.critical: 2}
    items = list(_alerts.values())
    if min_severity:
        items = [a for a in items if order[a.severity] >= order[min_severity]]
    return sorted(items, key=lambda a: (order[a.severity], a.timestamp), reverse=True)


# ---- Ingest from ANY diagnostic module (door/acv/rail_corrugation/shm) ----
# Every module in app/services/modules/ returns the same plain-dict shape
# regardless of rule-based vs ML implementation, so this is the ONE ingest
# function all of them go through. Adding a 5th subsystem needs no change here.

def ingest(source: str, alert_dicts: list[dict[str, Any]]) -> list[UnifiedAlert]:
    created = []
    for d in alert_dicts:
        ts = d.get("timestamp") or datetime.now(timezone.utc)
        asset_id = d.get("asset_id")
        alert = UnifiedAlert(
            id=_make_id(source, str(asset_id), str(ts), d.get("title", "")),
            source=source,
            asset_id=asset_id,
            severity=Severity(d["severity"]),
            title=d["title"],
            detail=d["detail"],
            timestamp=ts,
            raw=d.get("raw"),
        )
        upsert(alert)
        created.append(alert)
    return created


# ---- Ingest from live LTA feeds ----

async def refresh_lta_alerts(lta: LTAClient) -> list[UnifiedAlert]:
    created = []
    data = await lta.train_service_alerts()
    for item in data.get("value", []):
        status = item.get("Status")
        if str(status) == "1":  # 1 = normal service, nothing to surface
            continue
        alert = UnifiedAlert(
            id=_make_id("lta_tsa", item.get("Line", ""), str(item.get("Stations", ""))),
            source="lta_train_service_alerts",
            severity=Severity.critical,
            title=f"{item.get('Line')} service disruption",
            detail=item.get("Message", [{}])[0].get("Content", "") if item.get("Message") else "",
            timestamp=datetime.now(timezone.utc),
            raw=item,
        )
        upsert(alert)
        created.append(alert)

    fac = await lta.facilities_maintenance()
    for item in fac.get("value", []):
        alert = UnifiedAlert(
            id=_make_id("lta_fac", item.get("StationCode", ""), item.get("LiftID", "")),
            source="lta_facilities_maintenance",
            asset_id=item.get("LiftID"),
            severity=Severity.warning,
            title=f"Lift maintenance at {item.get('StationName')}",
            detail=item.get("LiftDesc", ""),
            timestamp=datetime.now(timezone.utc),
            raw=item,
        )
        upsert(alert)
        created.append(alert)

    return created
