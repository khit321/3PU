"""
Universal CSV Formatter (per master doc section 4.3): decouples module
output from the exact `*_predictions.csv` shape LTA wants, so a spec change
on Day 1/2 only touches this file -- and it works the same way regardless
of whether a subsystem is running in rule or model mode, since both modes
feed the same UnifiedAlert shape (see alert_engine.py).

IMPORTANT: LTA's `Problem_Statement_3_Specifications.md` (released with the
dataset) is the actual source of truth for column names/order. The shape
below is a best-guess placeholder and should be reconciled against that
spec the moment it drops.
"""
import os

import pandas as pd

from app.models.schemas import UnifiedAlert


def alerts_to_csv(alerts: list[UnifiedAlert], out_path: str) -> str:
    rows = [
        {
            "asset_id": a.asset_id,
            "timestamp": a.timestamp.isoformat(),
            "source": a.source,
            "severity": a.severity.value,
            "title": a.title,
            "detail": a.detail,
        }
        for a in alerts
    ]
    pd.DataFrame(rows).to_csv(out_path, index=False)
    return out_path


def ensure_output_dir(base_dir: str) -> str:
    os.makedirs(base_dir, exist_ok=True)
    return base_dir
