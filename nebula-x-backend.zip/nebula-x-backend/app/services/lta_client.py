"""
Thin async wrapper around LTA DataMall v2 REST APIs (see
LTA_DataMall_API_User_Guide.pdf, section 1 "MAKING API CALLS").

Auth: every call needs header  AccountKey: <LTA_ACCOUNT_KEY>  (no OAuth, no
request signing -- per the guide's Figure 2-1).

We only wrap the endpoints relevant to Problem Statement 3 (rail faults):
  - TrainServiceAlerts     (2.11) -- live disruption/fault notices
  - FacilitiesMaintenance  (2.23, v2) -- lift/escalator maintenance in MRT stations
  - PCDRealTime            (2.24) -- real-time station crowd density
  - PCDForecast            (2.25) -- forecast station crowd density

Add more `_get()` calls the same way for any other dataset your team needs
(Traffic Incidents, Faulty Traffic Lights, etc. -- see the guide's table of
contents for the full list of 30 datasets).

Every response is cached in-process for LTA_CACHE_TTL[endpoint] seconds so
the dashboard/chatbot can poll us as often as they like without us hammering
LTA's servers or burning through rate limits during the live demo.
"""
import time
from typing import Any, Optional

import httpx

from app.config import get_settings


class _TTLCache:
    def __init__(self):
        self._store: dict[str, tuple[float, Any]] = {}

    def get(self, key: str):
        entry = self._store.get(key)
        if not entry:
            return None
        expires_at, value = entry
        if time.time() > expires_at:
            del self._store[key]
            return None
        return value

    def set(self, key: str, value: Any, ttl: int):
        self._store[key] = (time.time() + ttl, value)


class LTAClient:
    def __init__(self):
        self.settings = get_settings()
        self._cache = _TTLCache()
        self._client = httpx.AsyncClient(
            base_url=self.settings.LTA_BASE_URL,
            headers={"AccountKey": self.settings.LTA_ACCOUNT_KEY, "accept": "application/json"},
            timeout=10.0,
        )

    async def _get(self, endpoint: str, params: Optional[dict] = None, v2: bool = False) -> dict:
        cache_key = f"{endpoint}:{params}"
        cached = self._cache.get(cache_key)
        if cached is not None:
            return cached

        path = f"/v2/{endpoint}" if v2 else f"/{endpoint}"
        resp = await self._client.get(path, params=params or {})
        resp.raise_for_status()
        data = resp.json()

        ttl = self.settings.LTA_CACHE_TTL.get(endpoint, self.settings.LTA_CACHE_TTL["default"])
        self._cache.set(cache_key, data, ttl)
        return data

    # ---- Rail-fault-relevant endpoints ----

    async def train_service_alerts(self) -> dict:
        """2.11 -- live train service unavailability (line/station/message)."""
        return await self._get("TrainServiceAlerts")

    async def facilities_maintenance(self, line: Optional[str] = None) -> dict:
        """2.23 -- adhoc lift maintenance in MRT stations. v2 endpoint."""
        params = {"Line": line} if line else None
        return await self._get("FacilitiesMaintenance", params=params, v2=True)

    async def station_crowd_density_realtime(self, train_line: str) -> dict:
        """2.24 -- requires TrainLine param, e.g. NEL, EWL, CCL..."""
        return await self._get("PCDRealTime", params={"TrainLine": train_line})

    async def station_crowd_density_forecast(self, train_line: str) -> dict:
        """2.25"""
        return await self._get("PCDForecast", params={"TrainLine": train_line})

    async def close(self):
        await self._client.aclose()


_client_singleton: Optional[LTAClient] = None


def get_lta_client() -> LTAClient:
    global _client_singleton
    if _client_singleton is None:
        _client_singleton = LTAClient()
    return _client_singleton
