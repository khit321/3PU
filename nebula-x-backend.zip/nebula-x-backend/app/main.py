import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import get_settings
from app.routers import alerts, chat, dashboard, lta, predictions
from app.services.modules.registry import get_module_registry

logging.basicConfig(level=logging.INFO)

app = FastAPI(
    title="Nebula X Backend",
    description="Predictive fault detection backend: AI models + LTA DataMall + chatbot, unified for the dashboard.",
    version="1.0.0",
)

settings = get_settings()
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(predictions.router)
app.include_router(alerts.router)
app.include_router(lta.router)
app.include_router(chat.router)
app.include_router(dashboard.router)


@app.on_event("startup")
async def load_modules():
    # Build all 4 diagnostic modules once, at boot, so the first request
    # isn't slow and so a bad model file / bad mode config fails fast
    # (visible in Cloud Run logs) instead of on someone's first request
    # during the demo.
    registry = get_module_registry()
    modes = {name: m.mode for name, m in registry.items()}
    logging.getLogger("nebula_x").info("Modules loaded, backend ready. Modes: %s", modes)


@app.get("/")
async def root():
    return {"service": "nebula-x-backend", "status": "ok"}


@app.get("/healthz")
async def healthz():
    """Cloud Run hits this (or /) to know the container is alive."""
    return {"status": "healthy"}
