"""
Run this AFTER `uvicorn app.main:app --reload` is already running in
another terminal. It uploads a tiny sample door-telemetry CSV (one door
segment with motor current spiking to 900mA, i.e. > the 800mA rule) so
there's a REAL alert sitting in the backend's shared alert feed -- the
same feed the chatbot's get_active_alerts tool reads from. Without this,
asking the chatbot "any alerts?" would correctly say "none," which proves
nothing about whether the tool-calling loop works.

Usage:
    python scripts/seed_door_alert.py
"""
import requests

BASE_URL = "http://localhost:8080"


def main():
    with open("data/sample_door_telemetry.csv", "rb") as f:
        resp = requests.post(f"{BASE_URL}/api/predictions/door", files={"file": f})
    resp.raise_for_status()
    print("Seeded via /api/predictions/door:")
    print(resp.json())

    alerts = requests.get(f"{BASE_URL}/api/alerts").json()
    print(f"\nBackend now holds {len(alerts)} alert(s) in the shared feed.")


if __name__ == "__main__":
    main()
