"""
Talks to your running backend's chatbot exactly like a dashboard would --
just from the terminal instead of a chat UI. Run scripts/seed_door_alert.py
first so there's a real alert for it to find.

Usage:
    python scripts/test_chat.py
"""
import requests

BASE_URL = "http://localhost:8080"
SESSION_ID = "terminal-test"


def ask(message: str):
    print(f"\nYou: {message}")
    resp = requests.post(
        f"{BASE_URL}/api/chat", json={"session_id": SESSION_ID, "message": message}
    )
    resp.raise_for_status()
    data = resp.json()
    print(f"Bot: {data['reply']}")
    if data["tool_calls"]:
        looked_up = [t["name"] for t in data["tool_calls"]]
        print(f"  (behind the scenes, it called: {looked_up})")


if __name__ == "__main__":
    ask("Are there any active alerts right now?")
    ask("Can you give me more detail on that door alert?")
    ask("Is that something operators should act on immediately?")
